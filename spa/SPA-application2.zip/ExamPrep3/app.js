import {getHome} from "./controllers/homeController.js";
import {getLogin} from "./controllers/userController.js";
import {getRegister} from "./controllers/userController.js";
import {postRegister} from "./controllers/userController.js";
import {logOutUser} from "./controllers/userController.js";
import {postLogin} from "./controllers/userController.js";
import {getCreate} from "./controllers/eventController.js";
import {postCreate} from "./controllers/eventController.js";
import {getDetails} from "./controllers/eventController.js";
import {getEdit} from "./controllers/eventController.js";
import {postEdit} from "./controllers/eventController.js";
import {closeEvent} from "./controllers/eventController.js";
import {getProfile} from "./controllers/userController.js";
import {joinEvent} from "./controllers/eventController.js";



const app = Sammy("body",function () {
    this.use("Handlebars", "hbs");

    this.get("#/home",getHome);

    this.get("#/login",getLogin);
    this.post("#/login",postLogin);

    this.get("#/register",getRegister);
    this.post("#/register",postRegister);

    this.get("#/logout",logOutUser);

    this.get("#/profile",getProfile);

    this.get("#/create",getCreate);
    this.post("#/create",postCreate);

    this.get("#/details/:id",getDetails);

    this.get("#/edit/:id",getEdit);
    this.post("#/edit/:id",postEdit);

    this.get("#/close/:id",closeEvent);

    this.get("#/join/:d",joinEvent)

});

app.run("#/home");