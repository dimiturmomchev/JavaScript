import {getTemplate} from "../helpers/helper.js";
import {checkContext} from "../helpers/helper.js";
import {getData} from "../helpers/storage.js";
import {create} from "../models/eventModel.js";
import {getEvent} from "../models/eventModel.js";
import {edit} from "../models/eventModel.js";
import {close} from "../models/eventModel.js";

export function getCreate(context) {
    let newContext = checkContext(context);
    getTemplate("events/create.hbs", newContext);
}

export function postCreate(context) {
    let data = {
        ...context.params,
        peopleInterestedIn: 0,
        organizer: JSON.parse(getData("userInfo")).username
    };
    create(data)
        .then(() => {
            context.redirect("#/home");
        })
        .catch(console.log);
}

export async function getDetails(context) {
    let newContext = checkContext(context);
    let event = await getEvent(context.params.id);

    Object.keys(event).forEach((key) => {
        newContext[key] = event[key];
    });

    newContext.isOrganizer = newContext.username === event.organizer;
    getTemplate("events/eventDetails.hbs", newContext);
}

export async function getEdit(context) {
    let newContext = checkContext(context);
    let event = await getEvent(context.params.id);

    Object.keys(event).forEach((key) => {
        newContext[key] = event[key];
    });

    getTemplate("events/editEvent.hbs", context);
}

export function postEdit(context) {
    let newContext = checkContext(context);
    console.log(context);
    let data = {
        ...context.params
    };
    delete data.id;
    edit(context.params.id,data)
        .then(() => {
            newContext.redirect(`#/details/${context.params.id}`);
        });
}

export async function closeEvent(context) {
    // let event = await getEvent(context.params.id);

    close(context.params.id)
        .then(()=>{
            context.redirect("#/home");
        })
}

export async function joinEvent(context) {
    let newContext = checkContext(context);
    let event = await getEvent(context.params.id);
    event.peopleInterestedIn++;

    Object.keys(event).forEach((key) => {
        newContext[key] = event[key];
    });

    edit(context.params.id,event)
        .then(()=>{
            newContext.redirect(`#/details/${context.params.id}`)
        })
        .catch(console.log);
}
