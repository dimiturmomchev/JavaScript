import {getTemplate} from "../helpers/helper.js";
import {checkContext} from "../helpers/helper.js";
import {getAllEvents} from "../models/eventModel.js";

export async function getHome(context) {
    let newContext = checkContext(context);
    let events = await getAllEvents();
    newContext.events= events;
    getTemplate("home.hbs",newContext);
}